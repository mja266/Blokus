let hours_worked = 146
